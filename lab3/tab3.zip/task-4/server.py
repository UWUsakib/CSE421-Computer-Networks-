import socket
import threading    
style="utf-8"
data=64
server_port=6969
hostname=socket.gethostname()
server_ip=socket.gethostbyname(hostname)
server_address=(server_ip,server_port)

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(server_address)
server.listen()
print(f"Server is listening ............")

def  progress(server_socket,client_address) :
    print(f"Connection from {client_address} has been established!  Congooo")
    connected=True
    while connected:
        new_message=server_socket.recv(data).decode(style)
        if new_message:
            msg=server_socket.recv(int(new_message)).decode(style)

            if msg=="exit":
                print(f"Client has left the chat {client_address}")
                connected=False
                server_socket.send("exit".encode(style))
                
            else:
                print(f"Message from client is : {msg}")
                
                if int(msg)<=40:
                    salary=200*int(msg)
                else:
                    i=int(msg)-40
                    salary=8000
                    for i in range(i):
                        salary+=300


                server_socket.send(str(salary).encode(style))

    server_socket.close()


while True:
    server_socket,client_address=server.accept()
    thread=threading.Thread(target=progress,args=(server_socket,client_address))
    thread.start()
    
    
                

