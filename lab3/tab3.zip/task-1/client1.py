import  socket
data=64
style="utf-8"
server_port=6969
hostname=socket.gethostname()
server_ip=socket.gethostbyname(hostname)
client_ip=socket.gethostbyname(hostname)
server_address=(server_ip,server_port)

client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(server_address)
 
def send_message(message):
    msg=message.encode(style)
    msg_length=len(msg)
    msg_lstring=str(msg_length).encode(style) + b" "*(data-len(str(msg_length)))
    
    client.send(msg_lstring)

    client.send(msg)
    server_response=client.recv(data).decode(style)
    print(f"Server response is : {server_response}")



send_message(f"client's device name is {hostname} and ip address is {client_ip}")
